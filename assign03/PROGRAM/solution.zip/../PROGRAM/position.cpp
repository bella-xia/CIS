#include "position.h"

Position::~Position()
{
}