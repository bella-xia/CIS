#include "rotation.h"

Rotation::~Rotation()
{
}